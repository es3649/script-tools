#!/usr/local/bin/python3.7

# clock.py - a command line time-card system
# Eric Steadman Copyright 2019
#
# TODO maybe make card nameable?
# TODO maybe tell the user what you did when you do it?

import copy
import datetime
import json
import os
import sys
import time
from os import path

COMMANDS = ('in', 'out', 'help', 'total', 'clear', 'show')
CARD_MAX = 5

CLOCK_LOCATION = '/home/'+ os.getenv('USER') +'/.clock_data'
CLOCK_LOCATION_OLD = '/home/'+ os.getenv('USER') + '/.clock_data.old'

#################
### Structure ###
#################
# {
#     "1": {
#         "cur": {
#             "in": 1565556903,
#             "out": 1565557532
#         },
#         "punches": [
#             {
#                 "in": 1565496539,
#                 "out": 1565499553
#             },
#             {
#                 "in": 1565556903,
#                 "out": 1565557532
#             }
#         ]
#     },
#     "2": {
#         "cur": {
#             "in": 1565557535
#         },
#         "punches": []
#     }
#     etc...
# }

def parseArgs():
    """
    Parses and verifies command line arguments
    use the help command to see what those arguments should be

    Return:
      (str): the command to execute
      (str): the number of the card to work on, or "0" if not provided
    """
    args = sys.argv
    # ensure argument counts
    if len(args) < 2:
        raise ValueError(f'Expected 1 argument, got {len(args)-1}')
    elif len(args) > 3:
        raise ValueError(f'Expected at most 2 arguments, got {len(args)-1}')

    # ensure valid command
    if args[1] not in COMMANDS:
        raise ValueError(f"Unknown command: '{args[1]}'")

    # if no card was provided:
    if len(args) < 3:
        return args[1], "0"

    # if it was, ensure existing card
    card = 0
    try:
        card = int(args[2])
    except:
        raise ValueError(f"Failed to convert '{args[2]}' to int")
    if card > CARD_MAX or card < 1:
        raise ValueError(f'Only {CARD_MAX} cards allowed')

    # return the card number as a string
    return args[1], args[2]

def usage():
    """
    Prints usage data. No args, no return
    """
    print(f'usage: {sys.argv[0]} COMMAND [CARD]')
    print("")
    print("Available commands are:")
    print(" in     punches in on the specified card")
    print(" out    punches out on the specified card")
    print(" show   shows time details for the specified card")
    print(" total  totals the time for the specified card")
    print(" clear  clears punches for the specified card")
    print(" help   displays this message")
    print("")
    print("Specify the card number after any command to run tha command on that")
    print(" card. Commands `show`, `total`, and `clear` can be used without a card")
    print(" number, in which case it runs against all cards.")
    print("")
    print(f"The system maintains {CARD_MAX} cards simultaneously")
    print("")
    print("When punching in while already in, punching out while already out")
    print(" or clearing the clock, confirmation is always requested. Then in/out")
    print(" punches will overwrite the previous saved in/out punch")
    print("")
    print(f"Timecard data is saved at {CLOCK_LOCATION}")
    print("")
    print("Created by Eric Steadman, Copyright 2019")
    print("Report bugs to es3649@gmail.com")

def get_card_json():
    """
    Gets the clock object from the data in the clock file

    Return:
      a dictionary representing the deserialized json
    """
    try:
        # check that the file exists
        if not path.exists(CLOCK_LOCATION):
            return dict()
        else:
            with open(CLOCK_LOCATION, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f'Failed to load json with error {str(e)}')
        raise e

def save_card_json(obj):
    """
    Takes an object to serialize and saves it to the clock file

    Arguments:
      obj (obj): the object to serialize and store.
    """
    with open(CLOCK_LOCATION, 'w+') as f:
        json.dump(obj, f, indent="  ")

    
def confirm(prompt, message=""):
    """
    Sends a message then gets a boolean representing a confirmation:
    True if they say yes, False if they say no
    """
    POSITIVE = ('y', 'Y', 'yes', 'Yes', 'YES')
    NEGATIVE = ('n', 'N', 'no', 'No', 'NO')
    while True:
        if message:
            print(message)
        resp = input(prompt + " (y/n) ")
        if resp in POSITIVE:
            return True
        elif resp in NEGATIVE:
            return False
        else:
            print("invalid input")
            print("")

def make_time(epoch_seconds):
    return datetime.datetime.fromtimestamp(epoch_seconds).strftime(r'%Y-%m-%d %H:%M:%S')

def make_time_hms(seconds):
    return time.strftime('%H:%M', time.gmtime(seconds))

def punch_in(full_card, card_num):
    """
    Punches in with the current time.
    If the last punch was an in punch, then request confirmation,
    then (if affirmative) replace the old in punch with the current time

    Arguments:
      card_number (str): String containing the number of the card to punch in on. Shall be >0
    """
    # get the card from the conglomerate
    if card_num in full_card:
        card = full_card[card_num]
    else:
        # initialize a new card
        card = dict()
        full_card[card_num] = card
        card["cur"] = dict()
        card["punches"] = list()
        print(f"Creating card {card_num}...")

    # grap the current punch
    cur_punch = card["cur"]
    # print(card)

    if "out" in cur_punch or "in" not in cur_punch:
        if "out" in cur_punch:
            # be sure to append a copy, because reference variables
            save = copy.deepcopy(cur_punch)
            card["punches"].append(save)
            del card["cur"]["out"]
        now = int(time.time())
        card["cur"]["in"] = now

        save_card_json(full_card)
        print(f'Punched in at: {make_time(now)}')
    else:
        if not confirm("Overwrite it?", "An 'in' punch already exists."):
            return 
        # else:
        now = int(time.time())
        card["cur"]["in"] = now
        print(f'Punch overridden, now in at: {make_time(now)}')
        return


def punch_out(full_card, card_num):
    """
    Punches out with the current time.
    If the last punch was an out punch, then request confirmation,
    then (if affirmative) replace the old out punch with the current time

    Arguments:
      full_card (dict): a dictionary containing the timecard data
      card_num (str): String containing the number of the card to punch out on. Shall be >0
    """
    # get the card data
    if card_num in full_card:
        card = full_card[card_num]
    else:
        # initialize a new card
        card = dict()
        full_card[card_num]
        card["cur"] = dict()
        card["punches"] = list()
        print(f"Card number {card_num} is not initialized")
        print("Initializing and not adding an out punch")
        return

    cur_punch = card["cur"]

    if "out" in cur_punch or "in" not in cur_punch:
        # if there is already an out punch
        if "out" in cur_punch:
            if not confirm("Overwrite it?", "An 'out' punch already exists."):
                return 
            # else:
            now = int(time.time())
            card["cur"]["out"] = now
            save_card_json(full_card)
            print(f'Punch overridden, now out at: {make_time(now)}')

        elif "in" not in cur_punch and len(card["punches"]) == 0:
            # if there are no punches (at all), we can't do anything
            print("Card has no punches (not even an in punch!)")
            print("Not adding an out punch")
            return

    else:
        now = int(time.time())
        card["cur"]["out"] = now
        save_card_json(full_card)
        print(f'Punched out at {make_time(now)}')


def subtotal(full_card, number):
    """
    Totals a single card (0 is invalid input)
    adds up the number of seconds on the record, and returns it

    Arguments:
      full_card (dict): the timecard object to total
      number (int): the number of the card to total

    Return:
      (int): the number of seconds on the card
      (bool): is the clock currently punched in?
    """
    # ensure the card exists
    if number not in full_card:
        print(f"Card {number} does not exist")
        return -1

    # get the card
    card = full_card[number]
    time_sum = 0
    if "in" in card["cur"]:
        punched_in = True

    # add the current punch
    if "out" in card["cur"]:
        time_sum += card["cur"]["out"]-card["cur"]["in"]
        punched_in = False

    # add each punch we've logged
    for punch in card["punches"]:
        time_sum += punch["out"]-punch["in"]

    return time_sum, punched_in

def total(card_full, number="0"):
    """
    Totals the time on the given card(s) and prints it
    This is a sub function of the show command.

    Arguments:
      card_full (dict): the card json data
      number (str): the number of the card to total, "0" to show all cards
    """
    if number == "0":
        for i in range(0, CARD_MAX):
            j = str(i+1)
            if j in card_full:
                sbt, is_in = subtotal(card_full,j)
                if is_in:
                    msg = " and clocked in"
                else:
                    msg = ""
                print(f"Total card {j}: {make_time_hms(sbt)}{msg}")
    else :
        sbt, is_in = subtotal(card_full,number)
        if sbt != -1:
            if is_in:
                msg = " and is clocked in"
            else:
                msg = ""
            print(f"Card {number} has {make_time_hms(sbt)}{msg}")

def show_one(full_card, card_number):
    """
    Displays the clock data on a single card.

    Arguments:
      full_card (dict): the card json data 
      number (str): the number of the card to show
    """
    print(f"===================== Card {card_number} =====================")
    # check existance
    if card_number not in full_card:
        print(f"Card {card_number} does not exist.")
        print(f"--------------------------------------------------")
        return

    card = full_card[card_number]

    for punch in card["punches"]:
        print(f'In: {make_time(punch["in"])}   Out: {make_time(punch["out"])}')
    
    if "out" in card["cur"]:
        print(f'In: {make_time(card["cur"]["in"])}   Out: {make_time(card["cur"]["out"])}')
    elif "in" in card["cur"]:
        print(f'In: {make_time(card["cur"]["in"])}   Out: --')
    
    # print a total for good measure
    print(f"--------------------------------------------------")
    total(full_card, card_number)

def show(full_card, card_number):
    """
    Shows time card data for the given card

    Arguments:
      full_card (dict): the json object holding the card
      card_number (str): String containing the number of the card to show, "0" to show all cards
    """
    if card_number == "0":
        for i in range(0,CARD_MAX):
            j = str(i+1)
            show_one(full_card, j)
            print("")
    
    else:
        show_one(full_card, card_number)
        

def clear(full_card, card_number):
    """
    Requests confirmation, then (if affirmative) clears all clock data from the cards.
    TODO: The data is moved to a '.old' file, whose contents are lost

    Arguments:
      full_card (dict): the json object holding the card
      card_number (str): the number of the card to clear, "0" to clear all cards
    """
    # display the cards for good measure
    show(full_card, card_number)

    if card_number != "0" and card_number not in full_card:
        print("Refusing to delete nonexistant card")
        return

    # get confirmation
    if not (confirm("Delete the selected card(s)?")):
        return

    #else
    if card_number == "0":
        for i in range(0,CARD_MAX):
            j = str(1+i)
            print(f"Deleting card {j}...")
            if j not in full_card:
                print("Refusing to delete nonexistant card")
                continue
            del full_card[j]
    else:
        print(f"Deleting card {card_number}...")
        del full_card[card_number]

    save_card_json(full_card)
    print("Cards have been cleared")

def main():
    cmd, card_num = 0, 0
    try:
        cmd, card_num = parseArgs()
    except ValueError as e:
        print(str(e))
        usage()
        return 1
    
    if cmd == 'help':
        usage()
        return 0

    card = get_card_json()
    if cmd == 'show':
        show(card, card_num)
    elif cmd == 'total':
        total(card, card_num)
    elif cmd == 'clear':
        clear(card, card_num)

    if card_num == "0":
        card_num = "1"
        
    if cmd == 'in':
        punch_in(card, card_num)
    elif cmd == 'out':
        punch_out(card, card_num)

    return 0

if __name__ == "__main__":
    main()